# MongoDB Atlas — Search, Vector Search & AI Agent POC

Demonstração técnica de um catálogo de marketplace com **5 milhões de documentos**, explorando as principais capacidades de busca e inteligência artificial do MongoDB Atlas.

O projeto nasceu da necessidade de ter uma base de dados genérica — desvinculada de qualquer cliente específico — que pudesse ser usada para demonstrar de forma clara e comparativa como o Atlas Search, Vector Search, Hybrid RRF e AI Agents funcionam na prática.

---

## O que está sendo demonstrado

### Atlas Search
Busca textual com autocomplete, fuzzy matching e facets em tempo real. A ideia aqui é mostrar que o Atlas Search vai muito além de um `find` com regex — ele indexa em paralelo com o MongoDB, suporta tolerância a erros de digitação e entrega facets agregados via `$searchMeta` sem precisar de uma query separada.

Queries interessantes para mostrar durante uma demo:
- `adidass` → corrige para Adidas (fuzzy, maxEdits: 1)
- `samsumg` → corrige para Samsung
- `notebokk` → corrige para notebook
- Ativar o toggle de Sinônimos e buscar `celular` → expande para smartphone, aparelho, telefone

### Search vs Vector Search
A comparação lado a lado é o ponto mais impactante da demo. O padrão que funciona bem:

| Query | Atlas Search | Vector Search |
|---|---|---|
| `academia em casa` | 0 resultados | Halteres, TRX, Kettlebell, Whey |
| `presente dia dos pais` | 0 resultados | Perfumes, Relógios, Livros |
| `proteção solar rosto` | 0 resultados | Protetor solar, Hidratante FPS |

O motivo do zero no Atlas Search: ele usa busca por frase exata no campo `nome` do produto. Como nenhum nome de produto contém "academia em casa" literalmente, retorna vazio. O Vector Search, por outro lado, entende o conceito e retorna produtos semanticamente relacionados — mesmo sem a palavra exata nos documentos.

### Hybrid RRF (Reciprocal Rank Fusion)
Combina os dois rankings anteriores usando a fórmula `score = Σ 1/(k + rank)`. Produtos que aparecem bem nos dois rankings acumulam score de ambos e sobem ao topo — marcados com 🏆 na tabela.

O k padrão é 60 (valor amplamente utilizado na literatura), mas o slider permite ajustar em tempo real para mostrar como ele afeta o ranking final.

Uma coisa importante de explicar durante a demo: queries ambíguas como `academia` podem trazer livros no lado vetorial porque "academia" em português tem dois significados (gym e instituição acadêmica). Isso não é bug — é o comportamento real de um modelo semântico. Para demos mais limpas, use `academia fitness` ou `equipamentos musculação`.

### AI Agent
LangGraph ReAct Agent com Claude Haiku e quatro ferramentas MongoDB:
- `busca_semantica` — `$vectorSearch` com autoEmbed
- `buscar_produto` — `$search` autocomplete + fuzzy
- `comparar_categoria` — aggregation `$match → $sort`
- `produtos_por_faixa_preco` — `$match` com range de preço

A memória de longo prazo é gravada via `MongoDBSaver` — cada sessão tem um `thread_id` e o histórico persiste mesmo após reiniciar a aplicação. Isso é visível quando você faz uma pergunta de acompanhamento sem repetir o contexto: `"E até R$ 5.000, o que muda?"` — o agent lembra que estava falando de notebooks.

---

## Arquitetura

```
Browser
  └── Streamlit (localhost:8501)
        ├── LangGraph ReAct Agent
        │     ├── Claude Haiku 4.5 (Anthropic)
        │     └── 4 ferramentas MongoDB
        └── PyMongo
              └── MongoDB Atlas
                    ├── produtos          (5M docs) ← Atlas Search index
                    ├── produtos_vector   (200K docs) ← Vector Search index (autoEmbed voyage-4)
                    ├── avaliacoes        (1M docs)
                    ├── checkpoints       ← memória do LangGraph
                    └── sinonimos         ← mapeamentos de sinônimos
```

O `produtos_vector` é um subset de `produtos` gerado via `$sample` — mantém a mesma estrutura mas num volume otimizado para o índice vetorial.

O autoEmbed é o ponto técnico mais relevante do Vector Search aqui: o embedding é gerado dentro do próprio Atlas (sem SDK externo), tanto na indexação quanto na query. Você passa uma string diretamente no `$vectorSearch` e o Atlas faz a conversão para vetor internamente via VoyageAI voyage-4.

---

## Pré-requisitos

- Python 3.11+
- Conta MongoDB Atlas (M10 ou superior recomendado para Search)
- API key Anthropic
- Integração VoyageAI ativa no Atlas (para autoEmbed)

---

## Setup

```bash
git clone https://github.com/adrianofratelli-glitch/SearchXVector---Agent-POC.git
cd SearchXVector---Agent-POC

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

Crie o arquivo `.env` baseado no `.env.example`:

```bash
cp .env.example .env
# edite com suas credenciais
```

---

## Populando os dados

```bash
# Padrão: 5M docs em produtos, 200K em produtos_vector, 1M em avaliacoes
python3 populate_marketplace.py

# Menor volume para testes rápidos (~5 min)
TOTAL_DOCS=500000 VECTOR_SAMPLE=50000 TOTAL_AVAL=100000 python3 populate_marketplace.py
```

O script cria as três collections, insere os dados em batches de 10K e cria os índices regulares ao final. Ele também imprime as instruções para criar os índices Atlas Search e Vector Search no Atlas UI.

---

## Índices no Atlas UI

Após popular os dados, crie os dois índices de busca.

**Atlas Search — collection `produtos`**

`Atlas UI → produtos → Search Indexes → Create → JSON Editor`

Nome: `produtos_search`

```json
{
  "mappings": {
    "dynamic": false,
    "fields": {
      "nome": [
        {
          "type": "autocomplete",
          "analyzer": "lucene.standard",
          "tokenization": "edgeGram",
          "minGrams": 2,
          "maxGrams": 15
        },
        { "type": "string", "analyzer": "lucene.standard" }
      ],
      "descricao":    { "type": "string", "analyzer": "lucene.portuguese" },
      "marca":        { "type": "string" },
      "categoria":    { "type": "stringFacet" },
      "subcategoria": { "type": "stringFacet" },
      "genero":       { "type": "stringFacet" },
      "em_estoque":   { "type": "boolean" },
      "preco":        { "type": "numberFacet" },
      "avaliacao_media": { "type": "number" }
    }
  },
  "synonyms": [
    {
      "name": "sinonimos_produtos",
      "analyzer": "lucene.standard",
      "source": { "collection": "sinonimos" }
    }
  ]
}
```

**Vector Search — collection `produtos_vector`**

`Atlas UI → produtos_vector → Search Indexes → Create → JSON Editor`

Nome: `produtos_vector`

```json
{
  "fields": [
    {
      "type": "autoEmbed",
      "path": "descricao",
      "modality": "text",
      "model": "voyage-4"
    },
    { "type": "filter", "path": "categoria" },
    { "type": "filter", "path": "em_estoque" },
    { "type": "filter", "path": "preco" }
  ]
}
```

O build do índice vetorial leva entre 20 e 40 minutos dependendo do volume. O Atlas Search fica disponível em alguns minutos.

**Sinônimos (opcional)**

```bash
mongosh "$MONGODB_URI" --eval '
db.getSiblingDB("POC").sinonimos.insertMany([
  { mappingType: "equivalent", synonyms: ["notebook", "laptop", "computador"] },
  { mappingType: "equivalent", synonyms: ["celular", "smartphone", "aparelho"] },
  { mappingType: "equivalent", synonyms: ["tênis", "calçado", "sapatênis", "sneaker"] },
  { mappingType: "equivalent", synonyms: ["fone", "headphone", "headset", "auricular"] },
  { mappingType: "equivalent", synonyms: ["tv", "televisão", "televisor"] },
  { mappingType: "equivalent", synonyms: ["perfume", "fragrância", "cologne"] },
  { mappingType: "equivalent", synonyms: ["academia", "musculação", "fitness", "gym"] }
])'
```

---

## Executando

```bash
source venv/bin/activate
streamlit run app_marketplace.py
```

Ou adicione um alias no `~/.zshrc` para abrir com um comando só:

```bash
alias marketplace="cd /caminho/do/projeto && source venv/bin/activate && streamlit run app_marketplace.py"
```

---

## Estrutura do projeto

```
.
├── app_marketplace.py       # Aplicação principal (Streamlit + LangGraph)
├── populate_marketplace.py  # Script de população dos dados sintéticos
├── requirements.txt
├── setup.sh                 # Bootstrap para EC2 (Amazon Linux)
├── start.sh                 # Start/restart em servidor
├── .env.example             # Template de variáveis de ambiente
├── .gitignore
└── README.md
```

---

## Notas técnicas

**Por que compound no Atlas Search do Tab 1?**
O autocomplete funciona bem para nomes de marca e modelo ("Nike", "Samsung"), mas uma query como "notebook" não aparece em nenhum nome de produto — os nomes são "MacBook Air", "Dell XPS 15", etc. O `compound` com `should` permite combinar autocomplete em `nome` (com boost) + text em `descricao`, garantindo que queries conceituais também retornem resultados.

**Por que phrase no Tab 2 (Search vs Vector)?**
Para criar o gap dramático da demo. O `phrase` busca a frase exata só no campo `nome` — nenhum nome de produto contém "academia em casa" ou "presente dia dos pais", então o Search retorna zero. O Vector encontra pela semântica. Se usássemos `text` em `descricao`, os templates de descrição conteriam essas frases e o gap desapareceria.

**maxTimeMS em todas as queries**
Todas as queries têm um timeout de 10 segundos aplicado via `maxTimeMS=10000`. Se o Atlas Search estiver sob pressão (cluster pequeno, índice em build, etc.), a operação é cancelada com uma mensagem clara em vez de travar a interface.

**synonyms + fuzzy não podem coexistir**
É uma limitação do Atlas Search — no operador `text`, você escolhe um dos dois. O toggle de sinônimos desativa o fuzzy automaticamente.

---

## Stack

- **MongoDB Atlas 8.0** — Search, Vector Search, Aggregation Framework
- **LangGraph** — ReAct Agent pattern + MongoDBSaver (memória)
- **Claude Haiku 4.5** — LLM via Anthropic API
- **VoyageAI voyage-4** — Embeddings via autoEmbed (sem SDK externo)
- **Streamlit** — Interface web

---

*POC desenvolvida para demonstração técnica — MongoDB Brasil — 2026*
